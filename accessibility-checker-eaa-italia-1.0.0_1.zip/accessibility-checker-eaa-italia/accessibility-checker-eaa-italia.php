<?php
/**
 * Plugin Name:       Accessibility Checker EAA Italia
 * Plugin URI:        https://www.agenziagraficamilano.it/sviluppo-siti-wordpress-milano/
 * Description:       Checks your pages for WCAG 2.2 AA accessibility issues (European Accessibility Act) directly in WordPress, in Italian. Printable report and accessibility statement draft. No external services.
 * Version:           1.0.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            Agenzia Grafica Milano
 * Author URI:        https://www.agenziagraficamilano.it/sviluppo-siti-wordpress-milano/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       accessibility-checker-eaa-italia
 *
 * @package A11yIT
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'A11YIT_VER', '1.0.0' );
define( 'A11YIT_FILE', __FILE__ );
define( 'A11YIT_URL', plugin_dir_url( __FILE__ ) );
define( 'A11YIT_META', '_a11yit_scan' );

require_once __DIR__ . '/includes/class-a11yit-scan.php';
require_once __DIR__ . '/includes/class-a11yit-fix.php';
require_once __DIR__ . '/includes/class-a11yit-admin.php';

A11YIT_Scan::init();
A11YIT_Fix::init();
if ( is_admin() ) {
	A11YIT_Admin::init();
}
