/* Accessibility Checker EAA Italia – browser scanner (runs axe-core inside a same-origin iframe). */
( function () {
	'use strict';
	var C = window.a11yitScan;
	if ( ! C ) {
		return;
	}
	var TAGS = [ 'wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa' ];
	var running = false;

	function wcag( tags ) {
		var out = [];
		( tags || [] ).forEach( function ( t ) {
			var m = /^wcag(\d)(\d)(\d+)$/.exec( t );
			if ( m ) {
				out.push( m[ 1 ] + '.' + m[ 2 ] + '.' + m[ 3 ] );
			}
		} );
		return out.join( ', ' );
	}

	function scanOne( item ) {
		return new Promise( function ( resolve, reject ) {
			var f = document.createElement( 'iframe' );
			var done = false;
			var timer = setTimeout( function () {
				finish( new Error( 'timeout' ) );
			}, 45000 );
			function finish( err, res ) {
				if ( done ) {
					return;
				}
				done = true;
				clearTimeout( timer );
				f.remove();
				if ( err ) {
					reject( err );
				} else {
					resolve( res );
				}
			}
			f.setAttribute( 'aria-hidden', 'true' );
			f.setAttribute( 'tabindex', '-1' );
			f.style.cssText = 'position:absolute;left:-10000px;top:0;width:1280px;height:900px;border:0;';
			f.onload = function () {
				var w = f.contentWindow, d;
				try {
					d = w.document;
				} catch ( e ) {
					finish( e );
					return;
				}
				var s = d.createElement( 'script' );
				s.src = C.axe;
				s.onload = function () {
					setTimeout( function () {
						try {
							if ( C.locale && window.a11yitAxeLocale ) {
								w.axe.configure( { locale: window.a11yitAxeLocale } );
							}
							w.axe.run( d, {
								runOnly: { type: 'tag', values: TAGS },
								resultTypes: [ 'violations' ],
							} ).then( function ( r ) {
								finish( null, r.violations.map( function ( v ) {
									return {
										id: v.id,
										impact: v.impact,
										help: v.help,
										description: v.description,
										helpUrl: v.helpUrl,
										wcag: wcag( v.tags ),
										count: v.nodes.length,
										nodes: v.nodes.slice( 0, 5 ).map( function ( n ) {
											return { target: ( n.target || [] ).join( ' ' ), html: n.html };
										} ),
									};
								} ) );
							} ).catch( finish );
						} catch ( e ) {
							finish( e );
						}
					}, 1500 );
				};
				s.onerror = function () {
					finish( new Error( 'axe' ) );
				};
				( d.head || d.documentElement ).appendChild( s );
			};
			f.src = item.url + ( item.url.indexOf( '?' ) > -1 ? '&' : '?' ) + 'a11yit_scan=1';
			document.body.appendChild( f );
		} );
	}

	function save( item, violations ) {
		return fetch( C.rest, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': C.nonce },
			body: JSON.stringify( { id: item.id, url: item.url, violations: violations } ),
		} ).then( function ( r ) {
			if ( ! r.ok ) {
				throw new Error( 'save' );
			}
			return r.json();
		} );
	}

	function run( items ) {
		if ( running || ! items.length ) {
			return;
		}
		running = true;
		var bar = document.getElementById( 'a11yit-progress' );
		var msg = document.getElementById( 'a11yit-status' );
		var i = 0;
		document.querySelectorAll( '.a11yit-scan-btn' ).forEach( function ( b ) {
			b.disabled = true;
		} );
		if ( bar ) {
			bar.hidden = false;
			bar.max = items.length;
			bar.value = 0;
		}
		function next() {
			if ( i >= items.length ) {
				if ( msg ) {
					msg.textContent = C.i18n.done;
				}
				setTimeout( function () {
					window.location.reload();
				}, 800 );
				return;
			}
			var it = items[ i ];
			if ( msg ) {
				msg.textContent = C.i18n.scanning.replace( '%1$d', i + 1 ).replace( '%2$d', items.length ).replace( '%3$s', it.title );
			}
			scanOne( it ).then( function ( v ) {
				return save( it, v );
			} ).catch( function () {
				if ( msg ) {
					msg.textContent = C.i18n.error.replace( '%s', it.title );
				}
			} ).then( function () {
				i++;
				if ( bar ) {
					bar.value = i;
				}
				next();
			} );
		}
		next();
	}

	document.addEventListener( 'click', function ( e ) {
		var b = e.target.closest( '.a11yit-scan-btn' );
		if ( ! b ) {
			return;
		}
		e.preventDefault();
		var id = b.getAttribute( 'data-id' );
		run( null === id ? C.items : C.items.filter( function ( x ) {
			return String( x.id ) === id;
		} ) );
	} );
}() );
