<?php
/**
 * Admin screens: overview, page details, printable report, accessibility statement.
 *
 * @package A11yIT
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin UI.
 */
class A11YIT_Admin {

	const HELP_URL = 'https://www.agenziagraficamilano.it/adeguamento-accessibilita-eaa/';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_a11yit_statement', array( __CLASS__, 'create_statement' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( A11YIT_FILE ), array( __CLASS__, 'links' ) );
	}

	/**
	 * Plugin list link.
	 *
	 * @param array $l Links.
	 * @return array
	 */
	public static function links( $l ) {
		array_unshift( $l, '<a href="' . esc_url( admin_url( 'admin.php?page=a11yit' ) ) . '">' . esc_html__( 'Check accessibility', 'accessibility-checker-eaa-italia' ) . '</a>' );
		return $l;
	}

	/**
	 * Menu.
	 */
	public static function menu() {
		add_menu_page( __( 'Accessibility', 'accessibility-checker-eaa-italia' ), __( 'Accessibility', 'accessibility-checker-eaa-italia' ), 'manage_options', 'a11yit', array( __CLASS__, 'page_overview' ), 'dashicons-universal-access-alt', 81 );
		add_submenu_page( 'a11yit', __( 'Accessibility check', 'accessibility-checker-eaa-italia' ), __( 'Check', 'accessibility-checker-eaa-italia' ), 'manage_options', 'a11yit', array( __CLASS__, 'page_overview' ) );
		add_submenu_page( 'a11yit', __( 'Accessibility report', 'accessibility-checker-eaa-italia' ), __( 'Report', 'accessibility-checker-eaa-italia' ), 'manage_options', 'a11yit-report', array( __CLASS__, 'page_report' ) );
		add_submenu_page( 'a11yit', __( 'Fixes applied', 'accessibility-checker-eaa-italia' ), __( 'Fixes applied', 'accessibility-checker-eaa-italia' ), 'manage_options', 'a11yit-fixes', array( __CLASS__, 'page_fixes' ) );
		add_submenu_page( 'a11yit', __( 'Accessibility statement', 'accessibility-checker-eaa-italia' ), __( 'Accessibility statement', 'accessibility-checker-eaa-italia' ), 'manage_options', 'a11yit-statement', array( __CLASS__, 'page_statement' ) );
	}

	/**
	 * Scripts and styles.
	 *
	 * @param string $hook Screen hook.
	 */
	public static function assets( $hook ) {
		if ( false === strpos( $hook, 'a11yit' ) ) {
			return;
		}
		wp_enqueue_style( 'a11yit-admin', A11YIT_URL . 'assets/admin.css', array(), A11YIT_VER );
		if ( 'toplevel_page_a11yit' !== $hook ) {
			return;
		}
		$it = 0 === strpos( determine_locale(), 'it' );
		if ( $it ) {
			wp_enqueue_script( 'a11yit-axe-it', A11YIT_URL . 'assets/axe-it.js', array(), A11YIT_VER, true );
		}
		wp_enqueue_script( 'a11yit-scanner', A11YIT_URL . 'assets/scanner.js', array(), A11YIT_VER, true );
		wp_localize_script(
			'a11yit-scanner',
			'a11yitScan',
			array(
				'items'  => A11YIT_Scan::targets(),
				'axe'    => A11YIT_URL . 'assets/axe.min.js?ver=' . A11YIT_VER,
				'locale' => $it,
				'rest'   => esc_url_raw( rest_url( 'a11yit/v1/result' ) ),
				'nonce'  => wp_create_nonce( 'wp_rest' ),
				'i18n'   => array(
					/* translators: 1: current page number, 2: total pages, 3: page title. */
					'scanning' => __( 'Checking %1$d of %2$d: %3$s…', 'accessibility-checker-eaa-italia' ),
					'done'     => __( 'Check complete. Updating results…', 'accessibility-checker-eaa-italia' ),
					/* translators: %s: page title. */
					'error'    => __( 'Could not check: %s', 'accessibility-checker-eaa-italia' ),
				),
			)
		);
	}

	/**
	 * Impact labels.
	 *
	 * @return array
	 */
	public static function impacts() {
		return array(
			'critical' => __( 'Critical', 'accessibility-checker-eaa-italia' ),
			'serious'  => __( 'Serious', 'accessibility-checker-eaa-italia' ),
			'moderate' => __( 'Moderate', 'accessibility-checker-eaa-italia' ),
			'minor'    => __( 'Minor', 'accessibility-checker-eaa-italia' ),
		);
	}

	/**
	 * Colored score badge.
	 *
	 * @param int|null $s Score.
	 * @return string HTML.
	 */
	public static function badge( $s ) {
		if ( null === $s ) {
			return '<span class="a11yit-score a11yit-na">—</span>';
		}
		$c = $s >= 90 ? 'good' : ( $s >= 60 ? 'mid' : 'bad' );
		return '<span class="a11yit-score a11yit-' . $c . '">' . (int) $s . '</span>';
	}

	/**
	 * Disclaimer shown on every screen.
	 */
	private static function disclaimer() {
		echo '<p class="a11yit-note">' . esc_html__( 'Automated checks find only part of the accessibility barriers. A good score does not mean the site is compliant with the European Accessibility Act: a manual review with keyboard and screen reader is always needed.', 'accessibility-checker-eaa-italia' ) . '</p>';
	}

	/**
	 * Help box (agency link).
	 */
	private static function help_box() {
		echo '<div class="a11yit-help"><strong>' . esc_html__( 'Need to comply with the EAA?', 'accessibility-checker-eaa-italia' ) . '</strong> ';
		echo esc_html__( 'Manual audit, fixes and accessibility statement by the developers of this plugin.', 'accessibility-checker-eaa-italia' ) . ' ';
		echo '<a href="' . esc_url( self::HELP_URL ) . '" target="_blank" rel="noopener">' . esc_html__( 'Request a free check', 'accessibility-checker-eaa-italia' ) . '</a></div>';
	}

	/**
	 * Overview and page details.
	 */
	public static function page_overview() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only view parameter.
		$detail = isset( $_GET['item'] ) ? absint( wp_unslash( $_GET['item'] ) ) : null;
		echo '<div class="wrap a11yit">';
		if ( null !== $detail ) {
			self::detail( $detail );
			echo '</div>';
			return;
		}
		$targets = A11YIT_Scan::targets();
		$sum     = A11YIT_Scan::summary( $targets );
		$imp     = self::impacts();
		echo '<h1>' . esc_html__( 'Accessibility check (WCAG 2.2 AA – EAA)', 'accessibility-checker-eaa-italia' ) . '</h1>';
		self::disclaimer();
		echo '<div class="a11yit-cards">';
		echo '<div class="a11yit-card"><span>' . esc_html__( 'Average score', 'accessibility-checker-eaa-italia' ) . '</span>' . wp_kses_post( self::badge( $sum['score'] ) ) . '</div>';
		/* translators: 1: checked pages, 2: total pages. */
		echo '<div class="a11yit-card"><span>' . esc_html__( 'Pages checked', 'accessibility-checker-eaa-italia' ) . '</span><b>' . esc_html( sprintf( __( '%1$d of %2$d', 'accessibility-checker-eaa-italia' ), $sum['scanned'], $sum['total'] ) ) . '</b></div>';
		foreach ( array( 'critical', 'serious' ) as $k ) {
			echo '<div class="a11yit-card"><span>' . esc_html( $imp[ $k ] ) . '</span><b class="a11yit-' . esc_attr( $k ) . '">' . (int) $sum['counts'][ $k ] . '</b></div>';
		}
		echo '</div>';
		echo '<p><button type="button" class="button button-primary a11yit-scan-btn">' . esc_html__( 'Check all pages', 'accessibility-checker-eaa-italia' ) . '</button> ';
		if ( $sum['scanned'] ) {
			echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=a11yit-report' ) ) . '">' . esc_html__( 'Open report', 'accessibility-checker-eaa-italia' ) . '</a> ';
			echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=a11yit-statement' ) ) . '">' . esc_html__( 'Create accessibility statement', 'accessibility-checker-eaa-italia' ) . '</a>';
		}
		echo '</p><progress id="a11yit-progress" hidden></progress> <span id="a11yit-status" role="status" aria-live="polite"></span>';

		echo '<table class="widefat striped a11yit-table"><thead><tr><th>' . esc_html__( 'Page', 'accessibility-checker-eaa-italia' ) . '</th><th>' . esc_html__( 'Score', 'accessibility-checker-eaa-italia' ) . '</th>';
		foreach ( $imp as $label ) {
			echo '<th>' . esc_html( $label ) . '</th>';
		}
		echo '<th>' . esc_html__( 'Last check', 'accessibility-checker-eaa-italia' ) . '</th><th></th></tr></thead><tbody>';
		foreach ( $targets as $t ) {
			$r = A11YIT_Scan::get( $t['id'] );
			echo '<tr><td><a href="' . esc_url( $t['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $t['title'] ) . '</a></td>';
			echo '<td>' . wp_kses_post( self::badge( $r ? (int) $r['score'] : null ) ) . '</td>';
			foreach ( array_keys( $imp ) as $k ) {
				echo '<td>' . ( $r ? (int) $r['counts'][ $k ] : '—' ) . '</td>';
			}
			echo '<td>' . ( $r ? esc_html( wp_date( get_option( 'date_format' ) . ' H:i', $r['time'] ) ) : '—' ) . '</td><td class="a11yit-actions">';
			if ( $r ) {
				echo '<a href="' . esc_url( admin_url( 'admin.php?page=a11yit&item=' . $t['id'] ) ) . '">' . esc_html__( 'Details', 'accessibility-checker-eaa-italia' ) . '</a> · ';
			}
			echo '<button type="button" class="button-link a11yit-scan-btn" data-id="' . (int) $t['id'] . '">' . esc_html__( 'Check', 'accessibility-checker-eaa-italia' ) . '</button></td></tr>';
		}
		echo '</tbody></table>';
		self::help_box();
		echo '</div>';
	}

	/**
	 * Issues of one page.
	 *
	 * @param int $id Post ID (0 = home).
	 */
	private static function detail( $id ) {
		$r     = A11YIT_Scan::get( $id );
		$title = $id ? get_the_title( $id ) : __( 'Home page', 'accessibility-checker-eaa-italia' );
		echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=a11yit' ) ) . '">← ' . esc_html__( 'All pages', 'accessibility-checker-eaa-italia' ) . '</a></p>';
		echo '<h1>' . esc_html( $title ) . ' ' . wp_kses_post( self::badge( $r ? (int) $r['score'] : null ) ) . '</h1>';
		if ( ! $r ) {
			echo '<p>' . esc_html__( 'This page has not been checked yet.', 'accessibility-checker-eaa-italia' ) . '</p>';
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only notice.
		if ( isset( $_GET['a11yit_saved'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$ok = '1' === sanitize_key( wp_unslash( $_GET['a11yit_saved'] ) );
			echo '<div class="notice ' . ( $ok ? 'notice-success' : 'notice-error' ) . ' inline"><p>' . ( $ok ? esc_html__( 'Fix saved. Check the page again to update the score.', 'accessibility-checker-eaa-italia' ) : esc_html__( 'The fix could not be saved for this element.', 'accessibility-checker-eaa-italia' ) ) . '</p></div>';
		}
		echo '<p><button type="button" class="button button-primary a11yit-scan-btn" data-id="' . (int) $id . '">' . esc_html__( 'Check this page again', 'accessibility-checker-eaa-italia' ) . '</button> <span id="a11yit-status" role="status" aria-live="polite"></span><progress id="a11yit-progress" hidden></progress></p>';
		self::issues( $r['violations'], true, admin_url( 'admin.php?page=a11yit&item=' . $id ) );
		self::help_box();
	}

	/**
	 * Issue list.
	 *
	 * @param array  $vs    Violations.
	 * @param bool   $nodes Show affected elements.
	 * @param string $back  Return URL for fix forms (empty = no fix forms).
	 */
	private static function issues( $vs, $nodes, $back = '' ) {
		$imp = self::impacts();
		if ( ! $vs ) {
			echo '<p class="a11yit-ok">' . esc_html__( 'No issues found by the automated check.', 'accessibility-checker-eaa-italia' ) . '</p>';
			return;
		}
		$order = array_flip( array_keys( $imp ) );
		usort(
			$vs,
			function ( $a, $b ) use ( $order ) {
				return $order[ $a['impact'] ] <=> $order[ $b['impact'] ];
			}
		);
		foreach ( $vs as $v ) {
			echo '<div class="a11yit-issue a11yit-b-' . esc_attr( $v['impact'] ) . '"><h3><span class="a11yit-tag a11yit-' . esc_attr( $v['impact'] ) . '">' . esc_html( $imp[ $v['impact'] ] ) . '</span> ' . esc_html( $v['help'] ) . '</h3>';
			echo '<p>' . esc_html( $v['desc'] );
			if ( $v['wcag'] ) {
				/* translators: %s: WCAG success criteria numbers. */
				echo ' <em>' . esc_html( sprintf( __( 'WCAG criterion: %s', 'accessibility-checker-eaa-italia' ), $v['wcag'] ) ) . '</em>';
			}
			/* translators: %d: number of elements. */
			echo ' · ' . esc_html( sprintf( _n( '%d element', '%d elements', $v['count'], 'accessibility-checker-eaa-italia' ), $v['count'] ) );
			if ( $v['url'] ) {
				echo ' · <a href="' . esc_url( $v['url'] ) . '" target="_blank" rel="noopener">' . esc_html__( 'Learn more', 'accessibility-checker-eaa-italia' ) . '</a>';
			}
			echo '</p>';
			$steps = A11YIT_Fix::guide( $v['id'] );
			if ( $steps ) {
				echo '<div class="a11yit-guide"><strong>' . esc_html__( 'How to fix it', 'accessibility-checker-eaa-italia' ) . '</strong><ol>';
				foreach ( $steps as $st ) {
					echo '<li>' . esc_html( $st ) . '</li>';
				}
				echo '</ol></div>';
			}
			if ( $back && 'meta-viewport' === $v['id'] ) {
				self::fix_form( array( 'zoom' => 1 ), $back, __( 'Allow zoom', 'accessibility-checker-eaa-italia' ) );
			}
			if ( $nodes && $v['nodes'] ) {
				echo '<ul class="a11yit-nodes">';
				foreach ( $v['nodes'] as $n ) {
					echo '<li><code>' . esc_html( $n['html'] ) . '</code>';
					if ( $back && isset( A11YIT_Fix::TEXT_RULES[ $v['id'] ] ) && A11YIT_Fix::signature( $n['html'] ) ) {
						self::text_fix( $v['id'], $n['html'], $back );
					}
					echo '</li>';
				}
				echo '</ul>';
			}
			echo '</div>';
		}
	}

	/**
	 * Small POST form for a fix.
	 *
	 * @param array  $fields Hidden fields.
	 * @param string $back   Return URL.
	 * @param string $label  Button label.
	 */
	private static function fix_form( $fields, $back, $label ) {
		echo '<form class="a11yit-fix" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="a11yit_fix"><input type="hidden" name="back" value="' . esc_attr( $back ) . '">';
		wp_nonce_field( 'a11yit_fix' );
		foreach ( $fields as $k => $val ) {
			echo '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( $val ) . '">';
		}
		echo '<button class="button button-primary">' . esc_html( $label ) . '</button></form>';
	}

	/**
	 * Inline text fix for one element.
	 *
	 * @param string $rule Rule ID.
	 * @param string $html Element snippet.
	 * @param string $back Return URL.
	 */
	private static function text_fix( $rule, $html, $back ) {
		$fix = A11YIT_Fix::find( $rule, $html );
		$uid = 'a11yit-f' . substr( md5( $rule . $html ), 0, 8 );
		echo '<form class="a11yit-fix" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="a11yit_fix"><input type="hidden" name="back" value="' . esc_attr( $back ) . '"><input type="hidden" name="rule" value="' . esc_attr( $rule ) . '"><input type="hidden" name="html" value="' . esc_attr( $html ) . '">';
		wp_nonce_field( 'a11yit_fix' );
		echo '<label for="' . esc_attr( $uid ) . '">' . esc_html__( 'Text', 'accessibility-checker-eaa-italia' ) . '</label> <input id="' . esc_attr( $uid ) . '" type="text" name="value" class="regular-text" value="' . esc_attr( $fix ? $fix['value'] : '' ) . '"> ';
		if ( 'image-alt' === $rule ) {
			echo '<label><input type="checkbox" name="decorative" value="1"' . checked( $fix && '' === $fix['value'], true, false ) . '> ' . esc_html__( 'Decorative image', 'accessibility-checker-eaa-italia' ) . '</label> ';
		}
		echo '<button class="button button-primary">' . esc_html__( 'Apply fix', 'accessibility-checker-eaa-italia' ) . '</button>';
		if ( $fix ) {
			echo ' <span class="a11yit-ok">✓ ' . esc_html__( 'Fix active', 'accessibility-checker-eaa-italia' ) . '</span>';
		}
		echo '</form>';
	}

	/**
	 * List of applied fixes.
	 */
	public static function page_fixes() {
		$fixes = A11YIT_Fix::all();
		echo '<div class="wrap a11yit"><h1>' . esc_html__( 'Fixes applied', 'accessibility-checker-eaa-italia' ) . '</h1>';
		echo '<p class="a11yit-note">' . esc_html__( 'Fixes are applied by the server when the page is generated: no script is added to the site, so speed and Core Web Vitals do not change. If you use a cache plugin, clear the cache after a change.', 'accessibility-checker-eaa-italia' ) . '</p>';
		if ( ! $fixes && ! get_option( 'a11yit_fix_zoom' ) ) {
			echo '<p>' . esc_html__( 'No fixes yet. Open the details of a page to fix its issues.', 'accessibility-checker-eaa-italia' ) . '</p></div>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Element', 'accessibility-checker-eaa-italia' ) . '</th><th>' . esc_html__( 'Fix', 'accessibility-checker-eaa-italia' ) . '</th><th></th></tr></thead><tbody>';
		if ( get_option( 'a11yit_fix_zoom' ) ) {
			echo '<tr><td><code>&lt;meta name="viewport"&gt;</code></td><td>' . esc_html__( 'Zoom allowed on phones', 'accessibility-checker-eaa-italia' ) . '</td><td>';
			self::unfix_form( 'zoom' );
			echo '</td></tr>';
		}
		foreach ( $fixes as $k => $f ) {
			$desc = array();
			foreach ( $f['attrs'] as $a => $v ) {
				$desc[] = $a . '="' . $v . '"';
			}
			echo '<tr><td><code>&lt;' . esc_html( $f['tag'] . ' ' . implode( ' ', $desc ) ) . '&gt;</code></td><td>' . esc_html( $f['attr'] ) . ' = "' . esc_html( $f['value'] ) . '"</td><td>';
			self::unfix_form( $k );
			echo '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	/**
	 * Remove button.
	 *
	 * @param string $key Fix key.
	 */
	private static function unfix_form( $key ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="a11yit_unfix"><input type="hidden" name="key" value="' . esc_attr( $key ) . '">';
		wp_nonce_field( 'a11yit_unfix' );
		echo '<button class="button-link a11yit-del">' . esc_html__( 'Remove', 'accessibility-checker-eaa-italia' ) . '</button></form>';
	}

	/**
	 * Printable report.
	 */
	public static function page_report() {
		$targets = A11YIT_Scan::targets();
		$sum     = A11YIT_Scan::summary( $targets );
		$imp     = self::impacts();
		echo '<div class="wrap a11yit a11yit-report">';
		echo '<p class="a11yit-noprint"><button type="button" class="button button-primary" onclick="window.print()">' . esc_html__( 'Print or save as PDF', 'accessibility-checker-eaa-italia' ) . '</button></p>';
		echo '<h1>' . esc_html__( 'Accessibility report', 'accessibility-checker-eaa-italia' ) . ' – ' . esc_html( get_bloginfo( 'name' ) ) . '</h1>';
		/* translators: 1: site URL, 2: date. */
		echo '<p>' . esc_html( sprintf( __( 'Site: %1$s · Date: %2$s · Standard: WCAG 2.2 level AA (EN 301 549, European Accessibility Act)', 'accessibility-checker-eaa-italia' ), home_url( '/' ), wp_date( get_option( 'date_format' ) ) ) ) . '</p>';
		if ( ! $sum['scanned'] ) {
			echo '<p>' . esc_html__( 'No pages checked yet.', 'accessibility-checker-eaa-italia' ) . '</p></div>';
			return;
		}
		echo '<div class="a11yit-cards"><div class="a11yit-card"><span>' . esc_html__( 'Average score', 'accessibility-checker-eaa-italia' ) . '</span>' . wp_kses_post( self::badge( $sum['score'] ) ) . '</div>';
		echo '<div class="a11yit-card"><span>' . esc_html__( 'Pages checked', 'accessibility-checker-eaa-italia' ) . '</span><b>' . (int) $sum['scanned'] . '</b></div>';
		foreach ( $imp as $k => $label ) {
			echo '<div class="a11yit-card"><span>' . esc_html( $label ) . '</span><b class="a11yit-' . esc_attr( $k ) . '">' . (int) $sum['counts'][ $k ] . '</b></div>';
		}
		echo '</div><h2>' . esc_html__( 'Issues to fix, by priority', 'accessibility-checker-eaa-italia' ) . '</h2>';
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Priority', 'accessibility-checker-eaa-italia' ) . '</th><th>' . esc_html__( 'Issue', 'accessibility-checker-eaa-italia' ) . '</th><th>WCAG</th><th>' . esc_html__( 'Pages', 'accessibility-checker-eaa-italia' ) . '</th><th>' . esc_html__( 'Elements', 'accessibility-checker-eaa-italia' ) . '</th></tr></thead><tbody>';
		foreach ( $sum['rules'] as $r ) {
			echo '<tr><td><span class="a11yit-tag a11yit-' . esc_attr( $r['impact'] ) . '">' . esc_html( $imp[ $r['impact'] ] ) . '</span></td><td>' . esc_html( $r['help'] ) . '</td><td>' . esc_html( $r['wcag'] ) . '</td><td>' . (int) $r['pages'] . '</td><td>' . (int) $r['count'] . '</td></tr>';
		}
		echo '</tbody></table><h2>' . esc_html__( 'Pages', 'accessibility-checker-eaa-italia' ) . '</h2><table class="widefat striped"><thead><tr><th>' . esc_html__( 'Page', 'accessibility-checker-eaa-italia' ) . '</th><th>' . esc_html__( 'Score', 'accessibility-checker-eaa-italia' ) . '</th>';
		foreach ( $imp as $label ) {
			echo '<th>' . esc_html( $label ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		foreach ( $targets as $t ) {
			$r = A11YIT_Scan::get( $t['id'] );
			if ( ! $r ) {
				continue;
			}
			echo '<tr><td>' . esc_html( $t['title'] ) . '<br><small>' . esc_html( $t['url'] ) . '</small></td><td>' . wp_kses_post( self::badge( (int) $r['score'] ) ) . '</td>';
			foreach ( array_keys( $imp ) as $k ) {
				echo '<td>' . (int) $r['counts'][ $k ] . '</td>';
			}
			echo '</tr>';
		}
		echo '</tbody></table>';
		self::disclaimer();
		/* translators: %s: plugin name. */
		echo '<p class="a11yit-note">' . esc_html( sprintf( __( 'Report generated with %s, based on axe-core.', 'accessibility-checker-eaa-italia' ), 'Accessibility Checker EAA Italia' ) ) . '</p>';
		self::help_box();
		echo '</div>';
	}

	/**
	 * Statement form.
	 */
	public static function page_statement() {
		$o    = wp_parse_args(
			get_option( 'a11yit_statement', array() ),
			array(
				'company' => get_bloginfo( 'name' ),
				'email'   => get_option( 'admin_email' ),
				'status'  => 'partial',
				'service' => '',
				'plan'    => '',
			)
		);
		$done = get_option( 'a11yit_statement_page' );
		echo '<div class="wrap a11yit"><h1>' . esc_html__( 'Accessibility statement', 'accessibility-checker-eaa-italia' ) . '</h1>';
		echo '<p>' . esc_html__( 'Creates a draft page with the accessibility statement, filled in with the results of the last check. Review it before publishing: it is a starting point, not legal advice.', 'accessibility-checker-eaa-italia' ) . '</p>';
		if ( $done && get_post( $done ) ) {
			/* translators: %s: edit link. */
			echo '<div class="notice notice-success inline"><p>' . wp_kses_post( sprintf( __( 'Draft created: %s', 'accessibility-checker-eaa-italia' ), '<a href="' . esc_url( get_edit_post_link( $done ) ) . '">' . esc_html( get_the_title( $done ) ) . '</a>' ) ) . '</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="a11yit_statement">';
		wp_nonce_field( 'a11yit_statement' );
		echo '<table class="form-table">';
		echo '<tr><th><label for="a11yit-company">' . esc_html__( 'Company name', 'accessibility-checker-eaa-italia' ) . '</label></th><td><input id="a11yit-company" type="text" class="regular-text" name="company" value="' . esc_attr( $o['company'] ) . '" required></td></tr>';
		echo '<tr><th><label for="a11yit-email">' . esc_html__( 'Accessibility contact email', 'accessibility-checker-eaa-italia' ) . '</label></th><td><input id="a11yit-email" type="email" class="regular-text" name="email" value="' . esc_attr( $o['email'] ) . '" required></td></tr>';
		echo '<tr><th><label for="a11yit-status">' . esc_html__( 'Compliance status', 'accessibility-checker-eaa-italia' ) . '</label></th><td><select id="a11yit-status" name="status">';
		foreach ( self::statuses() as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $o['status'], $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select></td></tr>';
		echo '<tr><th><label for="a11yit-service">' . esc_html__( 'Description of the service', 'accessibility-checker-eaa-italia' ) . '</label></th><td><textarea id="a11yit-service" class="large-text" rows="3" name="service" placeholder="' . esc_attr__( 'E.g. online shop for the sale of…', 'accessibility-checker-eaa-italia' ) . '">' . esc_textarea( $o['service'] ) . '</textarea></td></tr>';
		echo '<tr><th><label for="a11yit-plan">' . esc_html__( 'Fix plan', 'accessibility-checker-eaa-italia' ) . '</label></th><td><textarea id="a11yit-plan" class="large-text" rows="2" name="plan" placeholder="' . esc_attr__( 'E.g. the issues listed will be fixed by…', 'accessibility-checker-eaa-italia' ) . '">' . esc_textarea( $o['plan'] ) . '</textarea></td></tr>';
		echo '</table>';
		submit_button( __( 'Create draft page', 'accessibility-checker-eaa-italia' ) );
		echo '</form>';
		self::help_box();
		echo '</div>';
	}

	/**
	 * Compliance statuses.
	 *
	 * @return array
	 */
	private static function statuses() {
		return array(
			'full'    => __( 'Compliant', 'accessibility-checker-eaa-italia' ),
			'partial' => __( 'Partially compliant', 'accessibility-checker-eaa-italia' ),
			'none'    => __( 'Not compliant', 'accessibility-checker-eaa-italia' ),
		);
	}

	/**
	 * Build and save the statement draft.
	 */
	public static function create_statement() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'accessibility-checker-eaa-italia' ) );
		}
		check_admin_referer( 'a11yit_statement' );
		$st = self::statuses();
		$o  = array(
			'company' => isset( $_POST['company'] ) ? sanitize_text_field( wp_unslash( $_POST['company'] ) ) : '',
			'email'   => isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '',
			'status'  => isset( $_POST['status'] ) && isset( $st[ sanitize_key( $_POST['status'] ) ] ) ? sanitize_key( $_POST['status'] ) : 'partial',
			'service' => isset( $_POST['service'] ) ? sanitize_textarea_field( wp_unslash( $_POST['service'] ) ) : '',
			'plan'    => isset( $_POST['plan'] ) ? sanitize_textarea_field( wp_unslash( $_POST['plan'] ) ) : '',
		);
		update_option( 'a11yit_statement', $o, false );

		$sum  = A11YIT_Scan::summary( A11YIT_Scan::targets() );
		$date = wp_date( get_option( 'date_format' ) );
		$site = home_url( '/' );
		$h    = function ( $t ) {
			return "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . esc_html( $t ) . "</h2>\n<!-- /wp:heading -->\n\n";
		};
		$p    = function ( $t ) {
			return "<!-- wp:paragraph -->\n<p>" . $t . "</p>\n<!-- /wp:paragraph -->\n\n";
		};
		$c    = '';
		/* translators: 1: company, 2: site URL. */
		$c .= $p( esc_html( sprintf( __( '%1$s is committed to making its website %2$s accessible, in accordance with Legislative Decree 82/2022, which transposes Directive (EU) 2019/882 (European Accessibility Act).', 'accessibility-checker-eaa-italia' ), $o['company'], $site ) ) );
		if ( $o['service'] ) {
			$c .= $h( __( 'Description of the service', 'accessibility-checker-eaa-italia' ) ) . $p( esc_html( $o['service'] ) );
		}
		$c .= $h( __( 'Compliance status', 'accessibility-checker-eaa-italia' ) );
		/* translators: %s: compliance status. */
		$c .= $p( esc_html( sprintf( __( 'This website is %s with the requirements of the harmonised standard EN 301 549, which refers to the Web Content Accessibility Guidelines (WCAG) level AA.', 'accessibility-checker-eaa-italia' ), strtolower( $st[ $o['status'] ] ) ) ) );
		if ( 'full' !== $o['status'] && $sum['rules'] ) {
			$c .= $h( __( 'Non-accessible content', 'accessibility-checker-eaa-italia' ) );
			$c .= "<!-- wp:list -->\n<ul class=\"wp-block-list\">";
			foreach ( array_slice( $sum['rules'], 0, 10 ) as $r ) {
				$c .= '<!-- wp:list-item --><li>' . esc_html( $r['help'] ) . ( $r['wcag'] ? ' (WCAG ' . esc_html( $r['wcag'] ) . ')' : '' ) . '</li><!-- /wp:list-item -->';
			}
			$c .= "</ul>\n<!-- /wp:list -->\n\n";
			if ( $o['plan'] ) {
				$c .= $p( esc_html( $o['plan'] ) );
			}
		}
		$c .= $h( __( 'How this statement was prepared', 'accessibility-checker-eaa-italia' ) );
		/* translators: %s: date. */
		$c .= $p( esc_html( sprintf( __( 'Self-assessment carried out on %s with an automated check of the pages (axe-core), to be completed with a manual review.', 'accessibility-checker-eaa-italia' ), $date ) ) );
		$c .= $h( __( 'Feedback and contacts', 'accessibility-checker-eaa-italia' ) );
		/* translators: %s: email link. */
		$c .= $p( sprintf( esc_html__( 'To report accessibility problems or to request content in an accessible format, write to %s. We will reply as soon as possible.', 'accessibility-checker-eaa-italia' ), '<a href="mailto:' . esc_attr( $o['email'] ) . '">' . esc_html( $o['email'] ) . '</a>' ) );
		$c .= $h( __( 'Enforcement procedure', 'accessibility-checker-eaa-italia' ) );
		/* translators: %s: link to the AgID reporting platform. */
		$c .= $p( sprintf( esc_html__( 'If the reply is unsatisfactory or missing, you can file a report with AgID (Agenzia per l\'Italia Digitale) through %s.', 'accessibility-checker-eaa-italia' ), '<a href="https://segnalazioni.agid.gov.it/">segnalazioni.agid.gov.it</a>' ) );
		/* translators: %s: date. */
		$c .= $p( '<em>' . esc_html( sprintf( __( 'Statement drawn up on %s.', 'accessibility-checker-eaa-italia' ), $date ) ) . '</em>' );

		$args = array(
			'post_type'    => 'page',
			'post_status'  => 'draft',
			'post_title'   => __( 'Accessibility statement', 'accessibility-checker-eaa-italia' ),
			'post_content' => $c,
		);
		$old  = (int) get_option( 'a11yit_statement_page' );
		if ( $old && get_post( $old ) && 'publish' !== get_post_status( $old ) ) {
			$args['ID'] = $old;
		}
		$id = wp_insert_post( $args );
		if ( $id && ! is_wp_error( $id ) ) {
			update_option( 'a11yit_statement_page', $id, false );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=a11yit-statement' ) );
		exit;
	}
}
