<?php
/**
 * Scan storage, scoring and REST endpoint.
 *
 * @package A11yIT
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores scan results (post meta) and computes scores.
 */
class A11YIT_Scan {

	/**
	 * Score penalty per failed rule, by impact.
	 */
	const WEIGHTS = array(
		'critical' => 10,
		'serious'  => 5,
		'moderate' => 2,
		'minor'    => 1,
	);

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_filter( 'show_admin_bar', array( __CLASS__, 'hide_bar' ) );
	}

	/**
	 * Hide the admin bar on pages loaded by the scanner, so it is not audited.
	 *
	 * @param bool $show Show the bar.
	 * @return bool
	 */
	public static function hide_bar( $show ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only flag, no data is changed.
		return isset( $_GET['a11yit_scan'] ) ? false : $show;
	}

	/**
	 * REST routes.
	 */
	public static function routes() {
		register_rest_route(
			'a11yit/v1',
			'/result',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'save' ),
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
			)
		);
	}

	/**
	 * Post types that can be scanned.
	 *
	 * @return string[]
	 */
	public static function post_types() {
		$types = array( 'page', 'post' );
		if ( post_type_exists( 'product' ) ) {
			$types[] = 'product';
		}
		/**
		 * Filter the post types checked by the scanner.
		 *
		 * @param string[] $types Post type names.
		 */
		return apply_filters( 'a11yit_post_types', $types );
	}

	/**
	 * Published content to scan (home page first).
	 *
	 * @return array[] Items with id, title, url.
	 */
	public static function targets() {
		$items = array(
			array(
				'id'    => 0,
				'title' => __( 'Home page', 'accessibility-checker-eaa-italia' ),
				'url'   => home_url( '/' ),
			),
		);
		$front = (int) get_option( 'page_on_front' );
		$posts = get_posts(
			array(
				'post_type'      => self::post_types(),
				'post_status'    => 'publish',
				'posts_per_page' => (int) apply_filters( 'a11yit_max_pages', 200 ),
				'orderby'        => 'menu_order date',
				'order'          => 'ASC',
				'has_password'   => false,
				'fields'         => 'ids',
			)
		);
		foreach ( $posts as $id ) {
			if ( $id === $front ) {
				continue;
			}
			$items[] = array(
				'id'    => (int) $id,
				'title' => get_the_title( $id ) ? get_the_title( $id ) : '#' . $id,
				'url'   => get_permalink( $id ),
			);
		}
		return $items;
	}

	/**
	 * Read a stored result. ID 0 = home page (stored in an option).
	 *
	 * @param int $id Post ID.
	 * @return array|null
	 */
	public static function get( $id ) {
		$r = $id ? get_post_meta( $id, A11YIT_META, true ) : get_option( 'a11yit_home_scan' );
		return is_array( $r ) ? $r : null;
	}

	/**
	 * Save a result posted by the browser scanner.
	 *
	 * @param WP_REST_Request $req Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function save( $req ) {
		$id = absint( $req->get_param( 'id' ) );
		$vs = $req->get_param( 'violations' );
		if ( ( $id && ! get_post( $id ) ) || ! is_array( $vs ) ) {
			return new WP_Error( 'a11yit_bad', 'Bad request', array( 'status' => 400 ) );
		}
		$text   = function ( $v, $len = 400 ) {
			// Plain text: keep characters like "<li>" in rule names; always escaped on output.
			return substr( trim( preg_replace( '/[\x00-\x1F\x7F]+/', ' ', wp_check_invalid_utf8( (string) $v ) ) ), 0, $len );
		};
		$clean  = array();
		$counts = array_fill_keys( array_keys( self::WEIGHTS ), 0 );
		foreach ( array_slice( $vs, 0, 150 ) as $v ) {
			if ( ! is_array( $v ) || empty( $v['id'] ) ) {
				continue;
			}
			$impact = isset( $v['impact'] ) && isset( self::WEIGHTS[ $v['impact'] ] ) ? $v['impact'] : 'minor';
			++$counts[ $impact ];
			$nodes = array();
			if ( ! empty( $v['nodes'] ) && is_array( $v['nodes'] ) ) {
				foreach ( array_slice( $v['nodes'], 0, 5 ) as $n ) {
					$nodes[] = array(
						'target' => isset( $n['target'] ) ? $text( $n['target'], 300 ) : '',
						'html'   => isset( $n['html'] ) ? $text( $n['html'], 300 ) : '',
					);
				}
			}
			$clean[] = array(
				'id'     => sanitize_key( $v['id'] ),
				'impact' => $impact,
				'help'   => isset( $v['help'] ) ? $text( $v['help'] ) : '',
				'desc'   => isset( $v['description'] ) ? $text( $v['description'] ) : '',
				'url'    => isset( $v['helpUrl'] ) ? esc_url_raw( $v['helpUrl'] ) : '',
				'wcag'   => isset( $v['wcag'] ) ? sanitize_text_field( $v['wcag'] ) : '',
				'count'  => isset( $v['count'] ) ? absint( $v['count'] ) : count( $nodes ),
				'nodes'  => $nodes,
			);
		}
		$result = array(
			'time'       => time(),
			'url'        => esc_url_raw( (string) $req->get_param( 'url' ) ),
			'counts'     => $counts,
			'score'      => self::score( $counts ),
			'violations' => $clean,
		);
		if ( $id ) {
			update_post_meta( $id, A11YIT_META, $result );
		} else {
			update_option( 'a11yit_home_scan', $result, false );
		}
		return rest_ensure_response(
			array(
				'score'  => $result['score'],
				'counts' => $counts,
			)
		);
	}

	/**
	 * Score 0-100 from failed-rule counts.
	 *
	 * @param array $counts Counts by impact.
	 * @return int
	 */
	public static function score( $counts ) {
		$p = 0;
		foreach ( self::WEIGHTS as $k => $w ) {
			$p += $w * ( isset( $counts[ $k ] ) ? (int) $counts[ $k ] : 0 );
		}
		return max( 0, 100 - $p );
	}

	/**
	 * Site summary over all scanned items.
	 *
	 * @param array[] $targets Items from targets().
	 * @return array
	 */
	public static function summary( $targets ) {
		$s   = array(
			'scanned' => 0,
			'total'   => count( $targets ),
			'score'   => null,
			'counts'  => array_fill_keys( array_keys( self::WEIGHTS ), 0 ),
			'rules'   => array(),
		);
		$sum = 0;
		foreach ( $targets as $t ) {
			$r = self::get( $t['id'] );
			if ( ! $r ) {
				continue;
			}
			++$s['scanned'];
			$sum += (int) $r['score'];
			foreach ( $r['counts'] as $k => $n ) {
				$s['counts'][ $k ] += (int) $n;
			}
			foreach ( $r['violations'] as $v ) {
				if ( ! isset( $s['rules'][ $v['id'] ] ) ) {
					$s['rules'][ $v['id'] ] = array(
						'help'   => $v['help'],
						'impact' => $v['impact'],
						'wcag'   => $v['wcag'],
						'url'    => $v['url'],
						'pages'  => 0,
						'count'  => 0,
					);
				}
				++$s['rules'][ $v['id'] ]['pages'];
				$s['rules'][ $v['id'] ]['count'] += (int) $v['count'];
			}
		}
		if ( $s['scanned'] ) {
			$s['score'] = (int) round( $sum / $s['scanned'] );
		}
		$order = array_flip( array_keys( self::WEIGHTS ) );
		uasort(
			$s['rules'],
			function ( $a, $b ) use ( $order ) {
				return array( $order[ $a['impact'] ], -$a['pages'] ) <=> array( $order[ $b['impact'] ], -$b['pages'] );
			}
		);
		return $s;
	}
}
