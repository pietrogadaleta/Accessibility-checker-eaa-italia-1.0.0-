<?php
/**
 * Fixes: step-by-step guidance and server-side quick fixes (no JavaScript on the public site).
 *
 * @package A11yIT
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Guidance and quick fixes.
 */
class A11YIT_Fix {

	/**
	 * Rules that can be fixed by adding a text attribute to the element.
	 * Rule => attribute to add.
	 */
	const TEXT_RULES = array(
		'image-alt'       => 'alt',
		'input-image-alt' => 'alt',
		'role-img-alt'    => 'aria-label',
		'svg-img-alt'     => 'aria-label',
		'link-name'       => 'aria-label',
		'button-name'     => 'aria-label',
		'label'           => 'aria-label',
		'select-name'     => 'aria-label',
		'frame-title'     => 'title',
	);

	/**
	 * Attributes used to recognize the same element in the page.
	 */
	const KEYS = array( 'id', 'name', 'src', 'href', 'type', 'class', 'for', 'action' );

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'buffer' ), 1 );
		add_action( 'admin_post_a11yit_fix', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_a11yit_unfix', array( __CLASS__, 'remove' ) );
	}

	/**
	 * Saved fixes.
	 *
	 * @return array
	 */
	public static function all() {
		$f = get_option( 'a11yit_fixes', array() );
		return is_array( $f ) ? $f : array();
	}

	/**
	 * Recognize an element from the HTML snippet reported by the check.
	 *
	 * @param string $html Snippet.
	 * @return array|null Tag name and key attributes.
	 */
	public static function signature( $html ) {
		if ( ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
			return null;
		}
		$p = new WP_HTML_Tag_Processor( $html );
		if ( ! $p->next_tag() ) {
			return null;
		}
		$attrs = array();
		foreach ( self::KEYS as $k ) {
			$v = $p->get_attribute( $k );
			if ( is_string( $v ) && '' !== $v ) {
				$attrs[ $k ] = $v;
			}
		}
		if ( ! $attrs ) {
			return null;
		}
		return array(
			'tag'   => strtolower( $p->get_tag() ),
			'attrs' => $attrs,
		);
	}

	/**
	 * Start output processing on the public site, only when fixes exist.
	 */
	public static function buffer() {
		if ( is_admin() || is_feed() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}
		if ( ! self::all() && ! get_option( 'a11yit_fix_zoom' ) ) {
			return;
		}
		ob_start( array( __CLASS__, 'apply' ) );
	}

	/**
	 * Apply fixes to the page HTML. Runs on the server: no script is added to the page.
	 *
	 * @param string $html Page HTML.
	 * @return string
	 */
	public static function apply( $html ) {
		if ( ! is_string( $html ) || false === stripos( $html, '<html' ) ) {
			return $html;
		}
		if ( get_option( 'a11yit_fix_zoom' ) ) {
			$html = preg_replace_callback(
				'/<meta[^>]+name=["\']viewport["\'][^>]*>/i',
				function ( $m ) {
					$t = preg_replace( '/,?\s*(user-scalable\s*=\s*(no|0)|maximum-scale\s*=\s*[0-9.]+)/i', '', $m[0] );
					return str_replace( 'content=",', 'content="', $t );
				},
				$html
			);
		}
		$fixes = self::all();
		if ( ! $fixes || ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
			return $html;
		}
		$by_tag = array();
		foreach ( $fixes as $f ) {
			$by_tag[ $f['tag'] ][] = $f;
		}
		$p = new WP_HTML_Tag_Processor( $html );
		while ( $p->next_tag() ) {
			$tag = strtolower( $p->get_tag() );
			if ( empty( $by_tag[ $tag ] ) ) {
				continue;
			}
			foreach ( $by_tag[ $tag ] as $f ) {
				// Same key attributes, no more and no less.
				foreach ( self::KEYS as $k ) {
					$cur = $p->get_attribute( $k );
					$cur = is_string( $cur ) && '' !== $cur ? $cur : null;
					$exp = isset( $f['attrs'][ $k ] ) ? $f['attrs'][ $k ] : null;
					if ( $cur !== $exp ) {
						continue 2;
					}
				}
				$p->set_attribute( $f['attr'], $f['value'] );
				if ( 'alt' === $f['attr'] && 'img' === $tag && 'presentation' === $p->get_attribute( 'role' ) ) {
					$p->remove_attribute( 'role' );
				}
				break;
			}
		}
		return $p->get_updated_html();
	}

	/**
	 * Save a quick fix from the admin form.
	 */
	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'accessibility-checker-eaa-italia' ) );
		}
		check_admin_referer( 'a11yit_fix' );
		$back = isset( $_POST['back'] ) ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : admin_url( 'admin.php?page=a11yit' );
		if ( isset( $_POST['zoom'] ) ) {
			update_option( 'a11yit_fix_zoom', 1, false );
			wp_safe_redirect( add_query_arg( 'a11yit_saved', 1, $back ) );
			exit;
		}
		$rule  = isset( $_POST['rule'] ) ? sanitize_key( $_POST['rule'] ) : '';
		$html  = isset( $_POST['html'] ) ? wp_unslash( $_POST['html'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Parsed by WP_HTML_Tag_Processor, never output.
		$value = isset( $_POST['value'] ) ? sanitize_text_field( wp_unslash( $_POST['value'] ) ) : '';
		$sig   = self::signature( (string) $html );
		if ( ! isset( self::TEXT_RULES[ $rule ] ) || ! $sig || ( '' === $value && 'image-alt' !== $rule ) ) {
			wp_safe_redirect( add_query_arg( 'a11yit_saved', 0, $back ) );
			exit;
		}
		$attr = self::TEXT_RULES[ $rule ];
		// Decorative image: empty alt.
		if ( isset( $_POST['decorative'] ) && 'alt' === $attr ) {
			$value = '';
		}
		$fixes         = self::all();
		$key           = md5( wp_json_encode( $sig ) . $attr );
		$fixes[ $key ] = $sig + array(
			'attr'  => $attr,
			'value' => $value,
			'rule'  => $rule,
			'time'  => time(),
		);
		update_option( 'a11yit_fixes', $fixes, false );

		// Images from the Media Library: also save the alt text there, so it is used everywhere.
		if ( 'image-alt' === $rule && ! empty( $sig['attrs']['src'] ) && '' !== $value ) {
			$src = preg_replace( '/-\d+x\d+(?=\.[a-z]{3,4}$)/i', '', strtok( $sig['attrs']['src'], '?' ) );
			$aid = attachment_url_to_postid( $src );
			if ( $aid && ! get_post_meta( $aid, '_wp_attachment_image_alt', true ) ) {
				update_post_meta( $aid, '_wp_attachment_image_alt', $value );
			}
		}
		wp_safe_redirect( add_query_arg( 'a11yit_saved', 1, $back ) );
		exit;
	}

	/**
	 * Remove a quick fix.
	 */
	public static function remove() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'accessibility-checker-eaa-italia' ) );
		}
		check_admin_referer( 'a11yit_unfix' );
		$key = isset( $_POST['key'] ) ? sanitize_key( $_POST['key'] ) : '';
		if ( 'zoom' === $key ) {
			delete_option( 'a11yit_fix_zoom' );
		} else {
			$fixes = self::all();
			unset( $fixes[ $key ] );
			update_option( 'a11yit_fixes', $fixes, false );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=a11yit-fixes' ) );
		exit;
	}

	/**
	 * Existing fix for an element, if any.
	 *
	 * @param string $rule Rule ID.
	 * @param string $html Snippet.
	 * @return array|null
	 */
	public static function find( $rule, $html ) {
		$sig = self::signature( $html );
		if ( ! $sig || ! isset( self::TEXT_RULES[ $rule ] ) ) {
			return null;
		}
		$fixes = self::all();
		$key   = md5( wp_json_encode( $sig ) . self::TEXT_RULES[ $rule ] );
		return isset( $fixes[ $key ] ) ? $fixes[ $key ] : null;
	}

	/**
	 * Step-by-step guidance for the most common issues.
	 *
	 * @param string $rule axe rule ID.
	 * @return string[] Steps (empty when no specific guide exists).
	 */
	public static function guide( $rule ) {
		$g = array(
			'image-alt'                   => array(
				__( 'Write in the field below what the image shows or what it is for, in a short sentence.', 'accessibility-checker-eaa-italia' ),
				__( 'If the image is only decorative, tick "Decorative image": screen readers will skip it.', 'accessibility-checker-eaa-italia' ),
				__( 'For images in the Media Library, the text is also saved in the "Alternative text" field, so it is used on every page.', 'accessibility-checker-eaa-italia' ),
			),
			'link-name'                   => array(
				__( 'The link has no text, usually because it contains only an icon or an image.', 'accessibility-checker-eaa-italia' ),
				__( 'Write where the link leads (e.g. "Instagram page", "Go to cart") in the field below.', 'accessibility-checker-eaa-italia' ),
			),
			'button-name'                 => array(
				__( 'The button has no text, usually because it contains only an icon.', 'accessibility-checker-eaa-italia' ),
				__( 'Write what the button does (e.g. "Open menu", "Search") in the field below.', 'accessibility-checker-eaa-italia' ),
			),
			'label'                       => array(
				__( 'The form field has no label: a screen reader user does not know what to type.', 'accessibility-checker-eaa-italia' ),
				__( 'Quick fix: write the field name in the box below (e.g. "Email").', 'accessibility-checker-eaa-italia' ),
				__( 'Best fix: enable visible labels in your form plugin (Contact Form 7, Elementor Form, WPForms) instead of using only placeholders.', 'accessibility-checker-eaa-italia' ),
			),
			'select-name'                 => array(
				__( 'The drop-down menu has no label. Write its name in the field below (e.g. "Country").', 'accessibility-checker-eaa-italia' ),
			),
			'frame-title'                 => array(
				__( 'The embedded content (map, video, form) has no title. Write what it contains in the field below (e.g. "Map of our office").', 'accessibility-checker-eaa-italia' ),
			),
			'svg-img-alt'                 => array(
				__( 'The SVG image or icon has no text. Write what it represents in the field below.', 'accessibility-checker-eaa-italia' ),
			),
			'role-img-alt'                => array(
				__( 'The element is marked as an image but has no text. Write what it represents in the field below.', 'accessibility-checker-eaa-italia' ),
			),
			'input-image-alt'             => array(
				__( 'The image button has no text. Write what it does in the field below.', 'accessibility-checker-eaa-italia' ),
			),
			'color-contrast'              => array(
				__( 'The text color is too similar to the background. The minimum ratio is 4.5:1 for normal text and 3:1 for large text.', 'accessibility-checker-eaa-italia' ),
				__( 'Open the element in the editor (Elementor: Style tab → Color) and use a darker text or a lighter background.', 'accessibility-checker-eaa-italia' ),
				__( 'If the color comes from the theme, change it once in the global colors (Elementor: Site Settings → Global Colors).', 'accessibility-checker-eaa-italia' ),
			),
			'link-in-text-block'          => array(
				__( 'Links inside text are recognizable only by color. Underline them.', 'accessibility-checker-eaa-italia' ),
				__( 'Elementor: Site Settings → Typography → Link, or in the theme customizer.', 'accessibility-checker-eaa-italia' ),
			),
			'heading-order'               => array(
				__( 'Headings skip a level (e.g. from H2 to H4). Screen reader users navigate by headings.', 'accessibility-checker-eaa-italia' ),
				__( 'In the editor, change the heading level (HTML tag) to follow the order H1 → H2 → H3. Change the size with style, not with the level.', 'accessibility-checker-eaa-italia' ),
			),
			'list'                        => array(
				__( 'A list contains elements that are not list items. It usually comes from the menu of the theme or of a page builder.', 'accessibility-checker-eaa-italia' ),
				__( 'If it is in the menu, update the theme or the menu widget; if it is in a text block, rebuild the list with the list button of the editor.', 'accessibility-checker-eaa-italia' ),
			),
			'listitem'                    => array(
				__( 'A list item is outside a list. Rebuild the list with the list button of the editor.', 'accessibility-checker-eaa-italia' ),
			),
			'target-size'                 => array(
				__( 'The clickable element is smaller than 24 × 24 pixels and too close to others: it is hard to tap on a phone.', 'accessibility-checker-eaa-italia' ),
				__( 'Increase the padding of the button or icon, or the space between elements (Elementor: Advanced → Padding).', 'accessibility-checker-eaa-italia' ),
			),
			'meta-viewport'               => array(
				__( 'The site blocks zoom on phones. People with low vision cannot enlarge the text.', 'accessibility-checker-eaa-italia' ),
				__( 'Use the "Allow zoom" button below: the fix is applied on the server, with no impact on speed.', 'accessibility-checker-eaa-italia' ),
			),
			'html-has-lang'               => array(
				__( 'The page language is missing. Set it in Settings → General → Site Language; if it stays missing, the theme is overriding it.', 'accessibility-checker-eaa-italia' ),
			),
			'document-title'              => array(
				__( 'The page has no title. Check that the theme supports titles or set the title in your SEO plugin.', 'accessibility-checker-eaa-italia' ),
			),
			'duplicate-id-aria'           => array(
				__( 'Two elements have the same ID, so labels point to the wrong element. Usually caused by a widget used twice: change the ID in the Advanced settings of one of them.', 'accessibility-checker-eaa-italia' ),
			),
			'aria-hidden-focus'           => array(
				__( 'An element hidden from screen readers can still be reached with the keyboard. Often caused by sliders or hidden menus: update the plugin or disable the hidden copy.', 'accessibility-checker-eaa-italia' ),
			),
			'nested-interactive'          => array(
				__( 'A button or link contains another button or link. Remove one of the two in the editor (e.g. a button inside a card that is already a link).', 'accessibility-checker-eaa-italia' ),
			),
			'scrollable-region-focusable' => array(
				__( 'A scrollable area cannot be reached with the keyboard. Avoid boxes with internal scrolling or ask the developer to add tabindex="0".', 'accessibility-checker-eaa-italia' ),
			),
			'video-caption'               => array(
				__( 'The video has no subtitles. Add a subtitle file (.vtt) or use YouTube with subtitles enabled.', 'accessibility-checker-eaa-italia' ),
			),
			'autocomplete-valid'          => array(
				__( 'The field has a wrong autocomplete value. Use standard values (email, name, tel) in the field settings of your form plugin.', 'accessibility-checker-eaa-italia' ),
			),
			'aria-allowed-attr'           => array(
				__( 'An element uses an ARIA attribute that is not allowed for it. It usually comes from a plugin or theme: update it or report it to its developer.', 'accessibility-checker-eaa-italia' ),
			),
			'aria-required-children'      => array(
				__( 'A component (menu, tabs, list) is missing the elements it should contain. Update the plugin or widget that generates it.', 'accessibility-checker-eaa-italia' ),
			),
			'aria-prohibited-attr'        => array(
				__( 'An aria-label is used on an element that cannot have it. Remove it in the Advanced settings or attributes of the element.', 'accessibility-checker-eaa-italia' ),
			),
		);
		return isset( $g[ $rule ] ) ? $g[ $rule ] : array();
	}
}
