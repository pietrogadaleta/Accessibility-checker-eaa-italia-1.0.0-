<?php
/**
 * Remove plugin data.
 *
 * @package A11yIT
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
delete_option( 'a11yit_home_scan' );
delete_option( 'a11yit_statement' );
delete_option( 'a11yit_statement_page' );
delete_option( 'a11yit_fixes' );
delete_option( 'a11yit_fix_zoom' );
delete_post_meta_by_key( '_a11yit_scan' );
