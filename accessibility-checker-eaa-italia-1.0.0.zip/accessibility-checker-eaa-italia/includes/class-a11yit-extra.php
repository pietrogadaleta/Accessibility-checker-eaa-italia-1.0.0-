<?php
/**
 * Workflow tools: ignored issues, "show on page", list columns, score history, help box toggle.
 *
 * @package A11yIT
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Workflow tools.
 */
class A11YIT_Extra {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'wp_footer', array( __CLASS__, 'show_on_page' ), 99 );
		add_action( 'admin_post_a11yit_ignore', array( __CLASS__, 'ignore' ) );
		add_action( 'admin_post_a11yit_unignore', array( __CLASS__, 'unignore' ) );
		add_action( 'admin_post_a11yit_hide_help', array( __CLASS__, 'hide_help' ) );
		add_action( 'admin_init', array( __CLASS__, 'columns' ) );
	}

	/**
	 * Reasons for ignoring an issue.
	 *
	 * @return array
	 */
	public static function reasons() {
		return array(
			'false'  => __( 'False positive', 'accessibility-checker-eaa-italia' ),
			'manual' => __( 'Checked manually: accessible', 'accessibility-checker-eaa-italia' ),
			'later'  => __( 'Will be fixed later', 'accessibility-checker-eaa-italia' ),
		);
	}

	/**
	 * Ignored issues, by item ID and rule.
	 *
	 * @return array
	 */
	public static function ignored() {
		$i = get_option( 'a11yit_ignored', array() );
		return is_array( $i ) ? $i : array();
	}

	/**
	 * Remove ignored issues from a result and recompute counts and score.
	 *
	 * @param array $r  Stored result.
	 * @param int   $id Item ID.
	 * @return array
	 */
	public static function filter( $r, $id ) {
		$ign          = self::ignored();
		$r['ignored'] = array();
		if ( empty( $ign[ $id ] ) ) {
			return $r;
		}
		$keep   = array();
		$counts = array_fill_keys( array_keys( A11YIT_Scan::WEIGHTS ), 0 );
		foreach ( $r['violations'] as $v ) {
			if ( isset( $ign[ $id ][ $v['id'] ] ) ) {
				$v['reason']    = $ign[ $id ][ $v['id'] ]['reason'];
				$r['ignored'][] = $v;
				continue;
			}
			$keep[] = $v;
			++$counts[ $v['impact'] ];
		}
		$r['violations'] = $keep;
		$r['counts']     = $counts;
		$r['score']      = A11YIT_Scan::score( $counts );
		return $r;
	}

	/**
	 * Stop if the user cannot manage the plugin.
	 */
	private static function can() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'accessibility-checker-eaa-italia' ) );
		}
	}

	/**
	 * Ignore an issue on a page.
	 */
	public static function ignore() {
		self::can();
		check_admin_referer( 'a11yit_ignore' );
		$id     = isset( $_POST['item'] ) ? absint( $_POST['item'] ) : 0;
		$rule   = isset( $_POST['rule'] ) ? sanitize_key( $_POST['rule'] ) : '';
		$reason = isset( $_POST['reason'] ) ? sanitize_key( $_POST['reason'] ) : 'false';
		if ( $rule ) {
			$ign                 = self::ignored();
			$ign[ $id ][ $rule ] = array(
				'reason' => isset( self::reasons()[ $reason ] ) ? $reason : 'false',
				'time'   => time(),
				'user'   => get_current_user_id(),
			);
			update_option( 'a11yit_ignored', $ign, false );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=a11yit&item=' . $id ) );
		exit;
	}

	/**
	 * Restore an ignored issue.
	 */
	public static function unignore() {
		self::can();
		check_admin_referer( 'a11yit_unignore' );
		$id   = isset( $_POST['item'] ) ? absint( $_POST['item'] ) : 0;
		$rule = isset( $_POST['rule'] ) ? sanitize_key( $_POST['rule'] ) : '';
		$ign  = self::ignored();
		unset( $ign[ $id ][ $rule ] );
		if ( empty( $ign[ $id ] ) ) {
			unset( $ign[ $id ] );
		}
		update_option( 'a11yit_ignored', $ign, false );
		wp_safe_redirect( admin_url( 'admin.php?page=a11yit&item=' . $id ) );
		exit;
	}

	/**
	 * Hide the help box for the current user.
	 */
	public static function hide_help() {
		self::can();
		check_admin_referer( 'a11yit_hide_help' );
		$what = isset( $_POST['what'] ) && 'promo' === sanitize_key( wp_unslash( $_POST['what'] ) ) ? 'a11yit_hide_promo' : 'a11yit_hide_help';
		update_user_meta( get_current_user_id(), $what, 1 );
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=a11yit' ) );
		exit;
	}

	/**
	 * Small, dismissible suggestion for the free B2B Visitor Insights plugin.
	 * Shown only on this plugin's screens, to users who can install plugins,
	 * and only while that plugin is not installed.
	 */
	public static function promo_box() {
		if ( ! current_user_can( 'install_plugins' ) || get_user_meta( get_current_user_id(), 'a11yit_hide_promo', true ) ) {
			return;
		}
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		foreach ( array_keys( get_plugins() ) as $file ) {
			if ( 0 === strpos( $file, 'b2b-visitor-insights/' ) ) {
				return;
			}
		}
		$url = admin_url( 'plugin-install.php?s=' . rawurlencode( 'B2B Visitor Insights' ) . '&tab=search&type=term' );
		echo '<div class="a11yit-promo"><strong>' . esc_html__( 'Which companies visit your site?', 'accessibility-checker-eaa-italia' ) . '</strong> ';
		echo esc_html__( 'B2B Visitor Insights, free from the same developers, shows the companies that read your pages, with no monthly fee.', 'accessibility-checker-eaa-italia' ) . ' ';
		echo '<a class="button button-small" href="' . esc_url( $url ) . '">' . esc_html__( 'Get it free', 'accessibility-checker-eaa-italia' ) . '</a>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="a11yit-hide"><input type="hidden" name="action" value="a11yit_hide_help"><input type="hidden" name="what" value="promo">';
		wp_nonce_field( 'a11yit_hide_help' );
		echo '<button class="button-link">' . esc_html__( 'Hide', 'accessibility-checker-eaa-italia' ) . '</button></form></div>';
	}

	/**
	 * Public URL of an item.
	 *
	 * @param int $id Item ID (0 = home).
	 * @return string
	 */
	public static function url( $id ) {
		return $id ? (string) get_permalink( $id ) : home_url( '/' );
	}

	/**
	 * Link that opens the page with the element highlighted.
	 *
	 * @param int    $id     Item ID.
	 * @param string $target CSS selector reported by the check.
	 * @param string $label  Issue name.
	 * @return string
	 */
	public static function show_link( $id, $target, $label ) {
		return add_query_arg(
			array(
				'a11yit_show'  => rawurlencode( $target ),
				'a11yit_label' => rawurlencode( wp_html_excerpt( $label, 120, '…' ) ),
			),
			self::url( $id )
		);
	}

	/**
	 * Highlight an element on the public page. Only for administrators who opened
	 * a "Show on page" link: nothing is printed for visitors.
	 */
	public static function show_on_page() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only, administrators only.
		if ( empty( $_GET['a11yit_show'] ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$sel = sanitize_text_field( rawurldecode( wp_unslash( $_GET['a11yit_show'] ) ) );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Decoded, then sanitized.
		$label = isset( $_GET['a11yit_label'] ) ? sanitize_text_field( rawurldecode( wp_unslash( $_GET['a11yit_label'] ) ) ) : '';
		$js    = '(function(){var s=' . wp_json_encode( $sel ) . ',l=' . wp_json_encode( $label ) . ',e;try{e=Array.prototype.filter.call(document.querySelectorAll(s),function(n){return !n.closest("#wpadminbar");});}catch(x){return;}'
			. 'if(!e.length){return;}e.forEach(function(n){n.style.outline="4px solid #d63638";n.style.outlineOffset="3px";});'
			. 'var b=document.createElement("div");b.setAttribute("role","status");b.textContent=l;'
			. 'b.style.cssText="position:fixed;left:16px;bottom:16px;z-index:999999;max-width:420px;background:#d63638;color:#fff;font:600 14px/1.4 sans-serif;padding:10px 14px;border-radius:6px;box-shadow:0 4px 16px rgba(0,0,0,.3)";'
			. 'document.body.appendChild(b);e[0].scrollIntoView({block:"center"});})();';
		wp_print_inline_script_tag( $js );
	}

	/**
	 * Score column in the Pages, Posts and Products lists.
	 */
	public static function columns() {
		foreach ( A11YIT_Scan::post_types() as $pt ) {
			add_filter( "manage_{$pt}_posts_columns", array( __CLASS__, 'column_head' ) );
			add_action( "manage_{$pt}_posts_custom_column", array( __CLASS__, 'column_cell' ), 10, 2 );
		}
	}

	/**
	 * Column header.
	 *
	 * @param array $cols Columns.
	 * @return array
	 */
	public static function column_head( $cols ) {
		$cols['a11yit'] = __( 'Accessibility', 'accessibility-checker-eaa-italia' );
		return $cols;
	}

	/**
	 * Column cell.
	 *
	 * @param string $col Column.
	 * @param int    $id  Post ID.
	 */
	public static function column_cell( $col, $id ) {
		if ( 'a11yit' !== $col || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$r = A11YIT_Scan::get( (int) $id );
		if ( ! $r ) {
			echo '<a href="' . esc_url( admin_url( 'admin.php?page=a11yit' ) ) . '">' . esc_html__( 'Not checked', 'accessibility-checker-eaa-italia' ) . '</a>';
			return;
		}
		$issues = array_sum( $r['counts'] );
		echo '<a href="' . esc_url( admin_url( 'admin.php?page=a11yit&item=' . (int) $id ) ) . '">' . wp_kses_post( A11YIT_Admin::badge( (int) $r['score'] ) ) . '</a> ';
		/* translators: %d: number of issues. */
		echo '<small>' . esc_html( sprintf( _n( '%d issue', '%d issues', $issues, 'accessibility-checker-eaa-italia' ), $issues ) ) . '</small>';
	}

	/**
	 * Save today's average score and return the history.
	 *
	 * @param array $sum Site summary.
	 * @return array Date => score, oldest first.
	 */
	public static function history( $sum ) {
		$h = get_option( 'a11yit_history', array() );
		$h = is_array( $h ) ? $h : array();
		if ( null !== $sum['score'] && $sum['scanned'] ) {
			$h[ wp_date( 'Y-m-d' ) ] = (int) $sum['score'];
			ksort( $h );
			$h = array_slice( $h, -30, null, true );
			update_option( 'a11yit_history', $h, false );
		}
		return $h;
	}

	/**
	 * Small trend line (inline SVG).
	 *
	 * @param array $h History.
	 * @return string HTML.
	 */
	public static function sparkline( $h ) {
		$v = array_values( $h );
		$n = count( $v );
		if ( $n < 2 ) {
			return '';
		}
		$pts = array();
		foreach ( $v as $i => $s ) {
			$pts[] = round( $i * 120 / ( $n - 1 ), 1 ) . ',' . round( 30 - $s * 0.28, 1 );
		}
		$diff = $v[ $n - 1 ] - $v[ $n - 2 ];
		$txt  = ( $diff > 0 ? '+' : '' ) . $diff;
		/* translators: %s: score change, e.g. +4. */
		$lbl = sprintf( __( 'Change since the previous check: %s', 'accessibility-checker-eaa-italia' ), $txt );
		return '<svg class="a11yit-spark" width="120" height="32" viewBox="0 0 120 32" role="img" aria-label="' . esc_attr( $lbl ) . '"><polyline fill="none" stroke="#4b4a99" stroke-width="2" points="' . esc_attr( implode( ' ', $pts ) ) . '"/></svg> <b class="' . ( $diff >= 0 ? 'a11yit-up' : 'a11yit-down' ) . '">' . esc_html( $txt ) . '</b>';
	}
}
