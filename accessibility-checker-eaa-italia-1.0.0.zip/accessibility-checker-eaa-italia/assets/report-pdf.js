/* Accessibility Checker EAA Italia – downloadable PDF report (text-based, built in the browser). */
( function () {
	'use strict';
	var D = window.a11yitReport;
	var btn = document.getElementById( 'a11yit-pdf' );
	if ( ! D || ! btn || ! window.jspdf ) {
		return;
	}
	// Standard PDF fonts support Latin-1 only: map or drop other characters.
	function t( s ) {
		return String( null === s || undefined === s ? '' : s )
			.replace( /[→⇒]/g, '->' )
			.replace( /[“”]/g, '"' )
			.replace( /[‘’]/g, "'" )
			.replace( /[–—]/g, '-' )
			.replace( /…/g, '...' )
			.replace( /[^\x09\x0A\x0D\x20-\x7E\xA0-\xFF]/g, '' );
	}
	var COL = { critical: [ 138, 31, 17 ], serious: [ 179, 45, 46 ], moderate: [ 154, 103, 0 ], minor: [ 80, 87, 94 ] };
	var VIOLET = [ 75, 74, 153 ];

	btn.addEventListener( 'click', function () {
		var doc = new window.jspdf.jsPDF( { unit: 'mm', format: 'a4' } );
		var W = doc.internal.pageSize.getWidth();
		var y = 18;
		doc.setFont( 'helvetica', 'bold' );
		doc.setFontSize( 18 );
		doc.text( t( D.title ), 14, y );
		y += 7;
		doc.setFont( 'helvetica', 'normal' );
		doc.setFontSize( 9 );
		doc.setTextColor( 80 );
		doc.text( doc.splitTextToSize( t( D.meta ), W - 28 ), 14, y );
		y += 10;

		// Summary boxes.
		var boxes = D.cards, bw = ( W - 28 - ( boxes.length - 1 ) * 3 ) / boxes.length;
		boxes.forEach( function ( b, i ) {
			var x = 14 + i * ( bw + 3 );
			doc.setDrawColor( 200 );
			doc.roundedRect( x, y, bw, 18, 2, 2 );
			doc.setFontSize( 7.5 );
			doc.setTextColor( 80 );
			doc.text( t( b.label ), x + 3, y + 5 );
			doc.setFont( 'helvetica', 'bold' );
			doc.setFontSize( 14 );
			doc.setTextColor.apply( doc, b.color || [ 16, 17, 28 ] );
			doc.text( t( b.value ), x + 3, y + 14 );
			doc.setFont( 'helvetica', 'normal' );
		} );
		y += 26;

		doc.setTextColor( 16, 17, 28 );
		doc.setFont( 'helvetica', 'bold' );
		doc.setFontSize( 12 );
		doc.text( t( D.h_issues ), 14, y );
		doc.autoTable( {
			startY: y + 3,
			head: [ D.cols_issues.map( t ) ],
			body: D.rules.map( function ( r ) {
				return [ t( r.impact_label ), t( r.help ), t( r.wcag ), r.pages, r.count ];
			} ),
			styles: { fontSize: 8, cellPadding: 2, valign: 'top' },
			headStyles: { fillColor: VIOLET },
			columnStyles: { 0: { cellWidth: 22 }, 2: { cellWidth: 22 }, 3: { cellWidth: 14, halign: 'center' }, 4: { cellWidth: 16, halign: 'center' } },
			didParseCell: function ( c ) {
				if ( 'body' === c.section && 0 === c.column.index ) {
					var r = D.rules[ c.row.index ];
					c.cell.styles.textColor = COL[ r.impact ] || [ 0, 0, 0 ];
					c.cell.styles.fontStyle = 'bold';
				}
			},
		} );

		y = doc.lastAutoTable.finalY + 10;
		doc.setFont( 'helvetica', 'bold' );
		doc.setFontSize( 12 );
		doc.text( t( D.h_pages ), 14, y );
		doc.autoTable( {
			startY: y + 3,
			head: [ D.cols_pages.map( t ) ],
			body: D.pages.map( function ( p ) {
				return [ t( p.title ) + '\n' + t( p.url ), p.score ].concat( p.counts );
			} ),
			styles: { fontSize: 8, cellPadding: 2, valign: 'top' },
			headStyles: { fillColor: VIOLET },
			columnStyles: { 1: { halign: 'center', fontStyle: 'bold' }, 2: { halign: 'center' }, 3: { halign: 'center' }, 4: { halign: 'center' }, 5: { halign: 'center' } },
		} );

		y = doc.lastAutoTable.finalY + 8;
		if ( y > 260 ) {
			doc.addPage();
			y = 18;
		}
		doc.setFont( 'helvetica', 'normal' );
		doc.setFontSize( 8 );
		doc.setTextColor( 80 );
		var lines = doc.splitTextToSize( t( D.disclaimer ), W - 28 );
		doc.text( lines, 14, y );
		y += lines.length * 4 + 4;
		doc.setTextColor.apply( doc, VIOLET );
		doc.textWithLink( t( D.help ), 14, y, { url: D.help_url } );

		var n = doc.getNumberOfPages();
		for ( var i = 1; i <= n; i++ ) {
			doc.setPage( i );
			doc.setFontSize( 7.5 );
			doc.setTextColor( 120 );
			doc.text( t( D.footer ) + '  ' + i + '/' + n, 14, 290 );
		}
		doc.save( D.filename );
	} );
}() );
