=== Accessibility Checker EAA Italia ===
Contributors: YOUR-WPORG-USERNAME
Tags: accessibility, wcag, accessibility checker, european accessibility act, eaa
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Check your WordPress pages for WCAG 2.2 AA issues (European Accessibility Act), in Italian. Printable report and accessibility statement draft.

== Description ==

Accessibility Checker EAA Italia checks the pages of your site for accessibility barriers against WCAG 2.2 level AA, the reference of the European Accessibility Act (Directive (EU) 2019/882, Legislative Decree 82/2022 in Italy).

Everything runs inside your WordPress: the check uses the open-source axe-core engine in your browser. No account, no API key, no external service, no data sent anywhere.

**What it does**

* Checks the home page, pages, posts and WooCommerce products with one click.
* Gives every page a score from 0 to 100 and lists issues by priority: critical, serious, moderate, minor.
* Explains each issue in Italian (or English), with the WCAG criterion and the elements to fix.
* Step-by-step guide to fix each common issue, with instructions for the block editor and Elementor.
* Quick fixes without touching code: write the missing text for images, icon links, buttons, form fields and embeds, or allow zoom on phones. Fixes are applied by the server when the page is generated: no script is added to the site, so speed and Core Web Vitals do not change.
* "Show on page": opens the page with the element highlighted, so you know exactly what to fix.
* Ignore an issue on a page (false positive, checked manually, to fix later): it no longer counts in the score and you can restore it.
* Issues repeated on almost every page are marked "Whole site": they come from the theme, header or footer and are fixed once.
* Accessibility score column in the Pages, Posts and Products lists, and score trend over time.
* No account, no sign-up, no data sent anywhere. Suggestions in the plugin screens can be hidden with one click.
* PDF report to download and share with your team or client.
* Creates a draft "Accessibility statement" page with the results of the check, the contact email and the AgID reporting procedure.

**What it does not do**

This is not an overlay: it adds no JavaScript widget to your site. No automated tool can make a website compliant: automated checks find only part of the barriers. Use the results to fix the code, then complete them with a manual review (keyboard and screen reader).

**Who must comply**

In Italy, the European Accessibility Act applies to private companies offering services to consumers, such as e-commerce, banking and transport, since 28 June 2025. Micro-enterprises (fewer than 10 people and annual turnover or balance sheet up to 2 million euros) are exempt for services.

**No accounts, no nagging**

No sign-up, no API key and no notices on other admin screens. Only on the plugin's own screens you will see one small box about our accessibility services and one suggestion for our free plugin B2B Visitor Insights (only if it is not installed). Both can be hidden for good with one click, and nothing is tracked.

Developed by [Agenzia Grafica Milano](https://www.agenziagraficamilano.it/sviluppo-siti-wordpress-milano/).

== Installation ==

1. Install and activate the plugin.
2. Open **Accessibility → Check** and click **Check all pages**. Keep the tab open until the check ends.
3. Open the details of each page, fix the issues, then check again.
4. Use **Report** to download the PDF, and **Accessibility statement** to create the draft page.

== Frequently Asked Questions ==

= Does it make my site compliant with the EAA? =

No. No automated tool can. It shows the barriers that can be detected automatically, so you know where to start.

= Does it send data to external services? =

No. Pages are loaded and checked in your browser, inside the WordPress admin. Results are saved in your database.

= Does it slow down my site? =

No. No script or style is loaded on the public site. The checker runs only in the admin, when you start it. Quick fixes are applied by the server while the page is generated, and only when you have saved at least one fix. With a cache plugin, clear the cache after adding a fix.

= Which pages are checked? =

The home page and up to 200 published pages, posts and products. Developers can change this with the `a11yit_post_types` and `a11yit_max_pages` filters.

= Is the accessibility statement legally valid? =

It is a draft based on the results of the check. Review and complete it before publishing.

== Screenshots ==

1. Overview with average score and issues per page.
2. Issues of a page, explained in Italian.
3. PDF report.
4. Accessibility statement draft.

== Third-party libraries ==

* axe-core 4.14.0 by Deque Systems, Mozilla Public License 2.0 – https://github.com/dequelabs/axe-core (assets/axe.min.js, assets/axe-it.js)
* jsPDF 3.0.4, MIT License – https://github.com/parallax/jsPDF (assets/jspdf.umd.min.js)
* jsPDF-AutoTable 5.0.9, MIT License – https://github.com/simonbengtsson/jsPDF-AutoTable (assets/jspdf.plugin.autotable.min.js)

The "Learn more" links open the axe-core rule documentation on dequeuniversity.com in your browser.

== Changelog ==

= 1.0.0 =
* First release.
